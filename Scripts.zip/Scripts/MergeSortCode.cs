using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Linq;

public class MergeSortCode : MonoBehaviour
{
    public GameObject arBlockPrefab;
    public Transform arObjectsParent;
    public float spacing = 1.0f;
    public float animationSpeed = 1.0f;
    private MergeTableManage tableManager;


    private List<GameObject> arBlocks;


    void Start()
    {
        // Step 1: Spawn AR Blocks based on user input.
        SpawnARBlocks();

        // Step 2: Sort AR Blocks using Merge Sort.
        tableManager = FindObjectOfType<MergeTableManage>();
        // Add color-coding information
        string colorCodingInfo = "Blue = Divide\nRed = Compare\nGreen = Sorted for that division";
        tableManager.UpdateResultText(colorCodingInfo);

        if (tableManager == null)
        {
            Debug.LogError("MergeTableManage not found in the scene.");
        }
        else
        {
            StartCoroutine(MergeSortVisualization(0, arBlocks.Count - 1));
        }
    }

    // Step 1: Spawn AR Blocks based on user input.
    void SpawnARBlocks()
    {
        int[] inputNumbers = GetInputNumbers();
        Vector3 spawnPosition = Vector3.zero;

        arBlocks = new List<GameObject>();

        foreach (int number in inputNumbers)
        {
            GameObject arBlock = Instantiate(arBlockPrefab, arObjectsParent);
            TextMeshPro textMeshPro = arBlock.GetComponentInChildren<TextMeshPro>();

            if (textMeshPro != null)
            {
                textMeshPro.text = number.ToString();
                arBlocks.Add(arBlock);
            }
            else
            {
                Debug.LogError("TextMeshPro component not found in AR block prefab.");
            }

            arBlock.transform.position = spawnPosition;
            spawnPosition += new Vector3(spacing, 0f, 0f);
        }
    }

    // Step 2: Merge Sort Visualization.
    IEnumerator MergeSortVisualization(int low, int high)
    {
        if (low < high)
        {
            int mid = (low + high) / 2;


            // Visualize the division of arrays.
            yield return StartCoroutine(DivideArray(low, mid, high));

            yield return StartCoroutine(MergeSortVisualization(low, mid));
            yield return StartCoroutine(MergeSortVisualization(mid + 1, high));
            yield return StartCoroutine(Merge(low, mid, high));

            // Visualize the merged array.
            yield return StartCoroutine(MergeArray(low, mid, high));

        }
    }

    // Division visualization.
    IEnumerator DivideArray(int low, int mid, int high)
    {
        // Move the blocks apart to visualize division.
        for (int i = low; i <= high; i++)
        {
            Vector3 currentPos = arBlocks[i].transform.position;
            Vector3 targetPos = new Vector3(currentPos.x, currentPos.y + 15.0f, currentPos.z);
            Color targetColor = GetColorForStep("Division");
            yield return StartCoroutine(MoveAndColorOverSeconds(arBlocks[i], currentPos, targetPos, animationSpeed, targetColor));

        }

        // Wait for some time to visualize the current step.
        yield return new WaitForSeconds(animationSpeed);
    }

    // Merge visualization.
    IEnumerator MergeArray(int low, int mid, int high)
    {
        // Move the blocks back to their original positions.
        for (int i = low; i <= high; i++)
        {
            Vector3 currentPos = arBlocks[i].transform.position;
            Vector3 targetPos = new Vector3(currentPos.x, currentPos.y - 7.0f, currentPos.z);
            Color targetColor = GetColorForStep("Merge");
            yield return StartCoroutine(MoveAndColorOverSeconds(arBlocks[i], currentPos, targetPos, animationSpeed, targetColor));

        }

        // Wait for some time to visualize the current step.
        yield return new WaitForSeconds(animationSpeed);
    }

    // Merge step in Merge Sort.
    IEnumerator Merge(int low, int mid, int high)
    {
        int n1 = mid - low + 1;
        int n2 = high - mid;

        int[] leftArray = new int[n1];
        int[] rightArray = new int[n2];

        for (int x = 0; x < n1; ++x)
        {
            leftArray[x] = int.Parse(arBlocks[low + x].GetComponentInChildren<TextMeshPro>().text);
        }

        for (int y = 0; y < n2; ++y)
        {
            rightArray[y] = int.Parse(arBlocks[mid + 1 + y].GetComponentInChildren<TextMeshPro>().text);
        }

        int i = 0, j = 0;
        int k = low;

        while (i < n1 && j < n2)
        {
            if (leftArray[i] <= rightArray[j])
            {
                Color targetColor = GetColorForStep("Swap");
                yield return StartCoroutine(SwapNumbersVisual(arBlocks[k], leftArray[i], targetColor));
                i++;
            }
            else
            {
                Color targetColor = GetColorForStep("Swap");
                yield return StartCoroutine(SwapNumbersVisual(arBlocks[k], rightArray[j], targetColor));
                j++;
            }
            k++;

            // Wait for some time to visualize the current step.
            yield return new WaitForSeconds(animationSpeed);
        }

        while (i < n1)
        {
            Color targetColor = GetColorForStep("Swap");
            yield return StartCoroutine(SwapNumbersVisual(arBlocks[k], leftArray[i], targetColor));
            i++;
            k++;

            // Wait for some time to visualize the current step.
            yield return new WaitForSeconds(animationSpeed);
        }

        while (j < n2)
        {
            Color targetColor = GetColorForStep("Swap");
            yield return StartCoroutine(SwapNumbersVisual(arBlocks[k], rightArray[j], targetColor));
            j++;
            k++;

            // Wait for some time to visualize the current step.
            yield return new WaitForSeconds(animationSpeed);
        }

        // Display the result of the current iteration in the sorting table.
        string stepResult = $"Steps : {string.Join(", ", arBlocks.Select(block => block.GetComponentInChildren<TextMeshPro>().text))}";
        tableManager.UpdateResultText(stepResult);
        
    }

    // Swap numbers visualization.
    IEnumerator SwapNumbersVisual(GameObject arBlock, int newValue, Color targetColor)
    {
        Vector3 currentPos = arBlock.transform.position;
        Vector3 targetPos = new Vector3(currentPos.x, currentPos.y + 7.0f, currentPos.z);

        // Move the block up to visualize the swap.
        yield return StartCoroutine(MoveAndColorOverSeconds(arBlock, currentPos, targetPos, animationSpeed / 2.0f, targetColor));

        arBlock.GetComponentInChildren<TextMeshPro>().text = newValue.ToString();

        targetPos = new Vector3(currentPos.x, currentPos.y - 7.0f, currentPos.z);

        // Move the block down to its original position.
        yield return StartCoroutine(MoveAndColorOverSeconds(arBlock, currentPos, targetPos, animationSpeed / 2.0f, targetColor));
    }

    // Move AR Block and change color over a period of seconds.
    IEnumerator MoveAndColorOverSeconds(GameObject objectToMove, Vector3 start, Vector3 end, float seconds, Color targetColor)
    {
        float elapsedTime = 0;
        Color startColor = objectToMove.GetComponentInChildren<TextMeshPro>().color;

        while (elapsedTime < seconds)
        {
            objectToMove.transform.position = Vector3.Lerp(start, end, (elapsedTime / seconds));
            objectToMove.GetComponentInChildren<TextMeshPro>().color = Color.Lerp(startColor, targetColor, (elapsedTime / seconds));
            elapsedTime += Time.deltaTime;
            yield return new WaitForEndOfFrame();
        }

        objectToMove.transform.position = end;
        objectToMove.GetComponentInChildren<TextMeshPro>().color = targetColor;
    }

    // Get input numbers from PlayerPrefs.
    int[] GetInputNumbers()
    {
        string inputNumbersString = PlayerPrefs.GetString("InputNumbers", "");
        string[] inputStrings = inputNumbersString.Split(',');
        int[] inputNumbers = new int[inputStrings.Length];

        for (int i = 0; i < inputStrings.Length; i++)
        {
            if (int.TryParse(inputStrings[i], out int inputNumber))
            {
                inputNumbers[i] = inputNumber;
            }
        }

        return inputNumbers;
    }

    // Get color for each step based on step name.
    Color GetColorForStep(string stepName)
    {
        switch (stepName)
        {
            case "Division":
                return Color.blue; // Use any color you prefer for division.
            case "Merge":
                return Color.green; // Use any color you prefer for merging.
            case "Swap":
                return Color.red; // Use any color you prefer for swapping.
            default:
                return Color.white;
        }
    }
}
