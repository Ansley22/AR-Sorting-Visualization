using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Sortingbutton : MonoBehaviour
{
    public void SortGame()
	{
		SceneManager.LoadSceneAsync(2);
	}

}