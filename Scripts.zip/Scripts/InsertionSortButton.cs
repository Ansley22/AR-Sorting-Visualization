using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class InsertionSortButton : MonoBehaviour
{
        public void SortGame()
	{
		SceneManager.LoadSceneAsync(5);
	}

}
