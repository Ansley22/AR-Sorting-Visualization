using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonControl : MonoBehaviour
{
    public GameObject ball1; 
    public GameObject ball2; 

    public Button pauseButton; 
    public Button playButton; 

    private bool isPaused = false;

    private void Start()
    {
       
        pauseButton.onClick.AddListener(Pause);
        playButton.onClick.AddListener(Play);
    }

    private void Pause()
    {
        isPaused = true;
        Time.timeScale = 0; 
    }

    private void Play()
    {
        isPaused = false;
        Time.timeScale = 1; 

       
    }

    private void Update()
    {
        if (!isPaused)
        {
            
            RotateBalls();
        }
    }

    private void RotateBalls()
    {
        
        float rotationSpeed = 10f;
        Vector3 centerPosition = (ball1.transform.position + ball2.transform.position) / 2;
        ball1.transform.RotateAround(centerPosition, Vector3.up, rotationSpeed * Time.deltaTime);
        ball2.transform.RotateAround(centerPosition, Vector3.up, rotationSpeed * Time.deltaTime);
    }
}