using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class InputHandler : MonoBehaviour
{
    public TMP_InputField inputField;
    public TextMeshProUGUI numbersText;
    public Button submitButton;
    public Button removeButton; // Add a button for removing the last input.
    public Button clearButton;  // Add a button for clearing all input.
    
    private string inputNumbersString = ""; // Store the input numbers as a string.

    public void Start()
    {
        
        submitButton.onClick.AddListener(HandleInput);
        
        // Add a listener for the remove button.
        removeButton.onClick.AddListener(RemoveLastInput);

        // Add a listener for the clear button.
        clearButton.onClick.AddListener(ClearAllInput);

        // Retrieve the existing input numbers from PlayerPrefs, if any.
        inputNumbersString = PlayerPrefs.GetString("InputNumbers", "");
        numbersText.text = inputNumbersString; // Display the existing input.
    }

    public void HandleInput()
    {
        string inputText = inputField.text;
        if (int.TryParse(inputText, out int inputNumber))
        {
            // Input is a valid integer.
            Debug.Log("Input Number: " + inputNumber);

            // Append the new input number to the existing string.
            inputNumbersString += (inputNumbersString == "" ? "" : ",") + inputNumber;

            // Store the combined input numbers string in PlayerPrefs.
            PlayerPrefs.SetString("InputNumbers", inputNumbersString);

            // Display the entered number at the top.
            numbersText.text = inputNumbersString; // Display the entire list.
        }
        else
        {
            // Handle invalid input (e.g., show an error message).
            Debug.LogError("Invalid Input: " + inputText);
        }
    }

    public void RemoveLastInput()
    {
        // Split the input string by commas into an array.
        string[] inputArray = inputNumbersString.Split(',');

        if (inputArray.Length > 0)
        {
            // Remove the last element.
            inputArray = inputArray.SubArray(0, inputArray.Length - 1);

            // Join the array elements back into a string.
            inputNumbersString = string.Join(",", inputArray);

            // Update the PlayerPrefs and display.
            PlayerPrefs.SetString("InputNumbers", inputNumbersString);
            numbersText.text = inputNumbersString;
        }
    }

    public void ClearAllInput()
    {
        // Clear the stored input.
        inputNumbersString = "";
        PlayerPrefs.SetString("InputNumbers", inputNumbersString);
        numbersText.text = inputNumbersString;
    }
}

// Utility extension method for array slicing.
public static class ArrayExtensions
{
    public static T[] SubArray<T>(this T[] array, int startIndex, int length)
    {
        T[] result = new T[length];
        System.Array.Copy(array, startIndex, result, 0, length);
        return result;
    }
}