using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SelectionTableManager : MonoBehaviour
{
    public TextMeshProUGUI resultText; // Reference to the TextMeshPro Text
    private List<string> sortingSteps; // List to store sorting steps

    void Start()
    {
        sortingSteps = new List<string>();
    }

    // Function to update the result text
    public void UpdateResultText(string stepResult)
    {
        sortingSteps.Add(stepResult);
        UpdateText();
    }

    // Function to update the text displayed in the TextMeshPro Text
    private void UpdateText()
    {
        // Concatenate the steps and update the TextMeshPro Text
        resultText.text = string.Join("\n", sortingSteps);
    }

}
