using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class BubbleSortVisualizer : MonoBehaviour
{
    public GameObject[] arBallPrefab;
    public Transform arObjectsParent;
    public float animationSpeed = 1.0f;

    private GameObject[] arBall;

    void Start()
    {
       arBall = new GameObject[arBallPrefab.Length]; // Assuming arBallPrefab is an array.

        // Instantiate each arBallPrefab separately.
        for (int i = 0; i < arBallPrefab.Length; i++)
        {
            arBall[i] = Instantiate(arBallPrefab[i], arObjectsParent);
        }


        StartCoroutine(VisualizeBubbleSort());
    }

    IEnumerator VisualizeBubbleSort()
    {
        int n = arBall.Length;

        for (int i = 0; i < n - 1; i++)
        {
            for (int j = 0; j < n - i - 1; j++)
            {
                // Compare AR balls and animate if necessary.
                GameObject ball1 = arBall[j];
                GameObject ball2 = arBall[j + 1];

                TextMeshProUGUI text1 = ball1.GetComponentInChildren<TextMeshProUGUI>();
                TextMeshProUGUI text2 = ball2.GetComponentInChildren<TextMeshProUGUI>();

                // Debugging: Log the text values.
                Debug.Log("Text1: " + (text1 != null ? text1.text : "Text1 is null"));
                Debug.Log("Text2: " + (text2 != null ? text2.text : "Text2 is null"));

                int number1;
                int number2;

                if (int.TryParse(text1.text, out number1))
                {
                    Debug.Log("Number1: " + number1);
                }
                else
                {
                    Debug.LogError("Invalid number format for Text1: " + text1.text);
                }

                if (int.TryParse(text2.text, out number2))
                {
                    Debug.Log("Number2: " + number2);
                }
                else
                {
                    Debug.LogError("Invalid number format for Text2: " + text2.text);
                }


                // Continue with your sorting logic...

                if (number1 > number2)
                {
                    SwapBalls(ball1, ball2);
                }

                // Wait for some time to visualize the current step.
                yield return new WaitForSeconds(animationSpeed);
            }
        }
    }

    void SwapBalls(GameObject ball1, GameObject ball2)
    {
        // Animate the AR balls to show the swap visually.
        Vector3 pos1 = ball1.transform.position;
        Vector3 pos2 = ball2.transform.position;

        StartCoroutine(MoveOverSeconds(ball1, pos1, pos2, animationSpeed));
        StartCoroutine(MoveOverSeconds(ball2, pos2, pos1, animationSpeed));
    }

    IEnumerator MoveOverSeconds(GameObject objectToMove, Vector3 start, Vector3 end, float seconds)
    {
        float elapsedTime = 0;
        while (elapsedTime < seconds)
        {
            objectToMove.transform.position = Vector3.Lerp(start, end, (elapsedTime / seconds));
            elapsedTime += Time.deltaTime;
            yield return new WaitForEndOfFrame();
        }
        objectToMove.transform.position = end;
    }
}
