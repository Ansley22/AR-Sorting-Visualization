using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class WorstSelection : MonoBehaviour
{
    public GameObject arBallPrefab;
    public Transform arObjectsParent;
    public float spacing = 1.0f;
    public float animationSpeed = 1.0f;

    private List<GameObject> arBalls;

    void Start()
    {
        // Worst Case: Descending order input
        int[] inputNumbers = { 5, 4, 3, 2, 1 };

        // Spawn AR Balls based on user input.
        SpawnARObjects(inputNumbers);

        // Sort AR Balls using Selection Sort.
        StartCoroutine(SelectionSort());
    }

    void SpawnARObjects(int[] inputNumbers)
    {
        Vector3 spawnPosition = Vector3.zero;
        arBalls = new List<GameObject>();

        foreach (int number in inputNumbers)
        {
            GameObject arBall = Instantiate(arBallPrefab, arObjectsParent);
            TextMeshPro textMeshPro = arBall.GetComponentInChildren<TextMeshPro>();

            if (textMeshPro != null)
            {
                textMeshPro.text = number.ToString();
                arBalls.Add(arBall);
            }
            else
            {
                Debug.LogError("TextMeshPro component not found in AR ball prefab.");
            }

            arBall.transform.position = spawnPosition;
            spawnPosition += new Vector3(spacing, 0f, 0f);
        }
    }

    IEnumerator SelectionSort()
    {
        int n = arBalls.Count;



        for (int i = 0; i < n - 1; i++)
        {
            int minIndex = i;

            for (int j = i + 1; j < n; j++)
            {
                GameObject ball1 = arBalls[minIndex];
                GameObject ball2 = arBalls[j];

                TextMeshPro text1 = ball1.GetComponentInChildren<TextMeshPro>();
                TextMeshPro text2 = ball2.GetComponentInChildren<TextMeshPro>();

                int number1;
                int number2;

                if (int.TryParse(text1.text, out number1) && int.TryParse(text2.text, out number2))
                {
                    // Highlight the compared balls by changing their color to red
                    ChangeColor(text1, Color.red);
                    ChangeColor(text2, Color.red);

                    // Highlight the compared balls by increasing their size
                    yield return StartCoroutine(ScaleOverSeconds(ball1, new Vector3(1.5f, 1.5f, 1.5f), animationSpeed));
                    yield return StartCoroutine(ScaleOverSeconds(ball2, new Vector3(1.5f, 1.5f, 1.5f), animationSpeed));

                    yield return new WaitForSeconds(animationSpeed);

                    if (number2 < number1)
                    {
                        // Update the minimum index
                        minIndex = j;
                    }

                    // Reset the color after comparison
                    ChangeColor(text1, Color.white);
                    ChangeColor(text2, Color.white);

                    // Reset the size after comparison
                    yield return StartCoroutine(ScaleOverSeconds(ball1, Vector3.one, animationSpeed));
                    yield return StartCoroutine(ScaleOverSeconds(ball2, Vector3.one, animationSpeed));

                    // Wait for some time to visualize the current step.
                    yield return new WaitForSeconds(animationSpeed);
                }
                else
                {
                    Debug.LogError("Invalid number format for Text1 or Text2.");
                }
            }

            // Swap AR Balls if needed
            if (minIndex != i)
            {
                GameObject ball1 = arBalls[i];
                GameObject ball2 = arBalls[minIndex];

                // Swap AR Balls and continue with sorting logic.
                SwapBalls(ball1, ball2);
            }

        }

        // Change the color of all balls to green to indicate sorting completion
        foreach (GameObject arBall in arBalls)
        {
            TextMeshPro textMeshPro = arBall.GetComponentInChildren<TextMeshPro>();
            ChangeColor(textMeshPro, Color.green);
        }
    }

    void ChangeColor(TextMeshPro text, Color color)
    {
        if (text != null)
        {
            text.color = color;
        }
    }

    void SwapBalls(GameObject ball1, GameObject ball2)
    {
        Vector3 pos1 = ball1.transform.position;
        Vector3 pos2 = ball2.transform.position;

        StartCoroutine(MoveOverSeconds(ball1, pos1, pos2, animationSpeed));
        StartCoroutine(MoveOverSeconds(ball2, pos2, pos1, animationSpeed));

        // Swap AR Balls in the list.
        int index1 = arBalls.IndexOf(ball1);
        int index2 = arBalls.IndexOf(ball2);
        arBalls[index1] = ball2;
        arBalls[index2] = ball1;
    }

    IEnumerator MoveOverSeconds(GameObject objectToMove, Vector3 start, Vector3 end, float seconds)
    {
        float elapsedTime = 0;

        while (elapsedTime < seconds)
        {
            objectToMove.transform.position = Vector3.Lerp(start, end, (elapsedTime / seconds));
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        objectToMove.transform.position = end;
    }

    IEnumerator ScaleOverSeconds(GameObject objectToScale, Vector3 startScale, float seconds)
    {
        Vector3 endScale = objectToScale.transform.localScale;

        float elapsedTime = 0;

        while (elapsedTime < seconds)
        {
            objectToScale.transform.localScale = Vector3.Lerp(startScale, endScale, (elapsedTime / seconds));
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        objectToScale.transform.localScale = endScale;
    }
}
