using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class BestSelection : MonoBehaviour
{
    public GameObject arBallPrefab;
    public Transform arObjectsParent;
    public float spacing = 1.0f;
    public float animationSpeed = 1.0f;

    private List<GameObject> arBalls;

    void Start()
    {
        // Step 1: Spawn AR Balls with the best-case scenario.
        SpawnARObjectsBestCase();

        // Step 2: Sort AR Balls using Selection Sort.
        StartCoroutine(SelectionSort());
    }

    // Step 1: Spawn AR Balls with the best-case scenario (already sorted).
    void SpawnARObjectsBestCase()
    {
        int[] inputNumbers = { 1, 2, 3, 4, 5 }; // Best-case scenario
        Vector3 spawnPosition = Vector3.zero;

        arBalls = new List<GameObject>();

        foreach (int number in inputNumbers)
        {
            GameObject arBall = Instantiate(arBallPrefab, arObjectsParent);
            TextMeshPro textMeshPro = arBall.GetComponentInChildren<TextMeshPro>();

            if (textMeshPro != null)
            {
                textMeshPro.text = number.ToString();
                arBalls.Add(arBall);
            }
            else
            {
                Debug.LogError("TextMeshPro component not found in AR ball prefab.");
            }

            arBall.transform.position = spawnPosition;
            spawnPosition += new Vector3(spacing, 0f, 0f);
        }
    }

    // Step 2: Selection Sort AR Balls.
    IEnumerator SelectionSort()
    {
        int n = arBalls.Count;

        for (int i = 0; i < n - 1; i++)
        {
            int minIndex = i;

            for (int j = i + 1; j < n; j++)
            {
                GameObject ball1 = arBalls[minIndex];
                GameObject ball2 = arBalls[j];

                TextMeshPro text1 = ball1.GetComponentInChildren<TextMeshPro>();
                TextMeshPro text2 = ball2.GetComponentInChildren<TextMeshPro>();

                // Highlight the compared balls by changing their color to red
                ChangeColor(text1, Color.red);
                ChangeColor(text2, Color.red);

                // Highlight the compared balls by increasing their size
                yield return StartCoroutine(ScaleOverSeconds(ball1, new Vector3(1.5f, 1.5f, 1.5f), animationSpeed));
                yield return StartCoroutine(ScaleOverSeconds(ball2, new Vector3(1.5f, 1.5f, 1.5f), animationSpeed));

                yield return new WaitForSeconds(animationSpeed);

                // Reset the color and size after comparison
                ChangeColor(text1, Color.white);
                ChangeColor(text2, Color.white);
                yield return StartCoroutine(ScaleOverSeconds(ball1, Vector3.one, animationSpeed));
                yield return StartCoroutine(ScaleOverSeconds(ball2, Vector3.one, animationSpeed));
            }

            // No swaps needed in the best case, so no need to update the table result.

            yield return new WaitForSeconds(animationSpeed);
        }

        // Change the color of all balls to green to indicate sorting completion
        foreach (GameObject arBall in arBalls)
        {
            TextMeshPro textMeshPro = arBall.GetComponentInChildren<TextMeshPro>();
            ChangeColor(textMeshPro, Color.green);
        }
    }

    // Change the color of TextMeshPro component
    void ChangeColor(TextMeshPro text, Color color)
    {
        if (text != null)
        {
            text.color = color;
        }
    }

    // Scale AR Ball over a period of seconds.
    IEnumerator ScaleOverSeconds(GameObject objectToScale, Vector3 startScale, float seconds)
    {
        Vector3 endScale = objectToScale.transform.localScale;

        float elapsedTime = 0;

        while (elapsedTime < seconds)
        {
            objectToScale.transform.localScale = Vector3.Lerp(startScale, endScale, (elapsedTime / seconds));
            elapsedTime += Time.deltaTime;
            yield return new WaitForEndOfFrame();
        }

        objectToScale.transform.localScale = endScale;
    }
}
