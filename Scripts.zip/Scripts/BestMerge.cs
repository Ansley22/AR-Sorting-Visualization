using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class BestMerge : MonoBehaviour
{
    public GameObject arBlockPrefab;
    public Transform arObjectsParent;
    public float spacing = 1.0f;
    public float animationSpeed = 1.0f;

    private List<GameObject> arBlocks;

    void Start()
    {

        // Worst Case: Descending order input
        int[] inputNumbers = { 1, 2, 3, 4, 5 };

        // Spawn AR Blocks based on user input.
        SpawnARBlocks(inputNumbers);

        // Sort AR Blocks using Merge Sort.
        StartCoroutine(MergeSortVisualization(0, arBlocks.Count - 1));
    }

    void SpawnARBlocks(int[] inputNumbers)
    {
        Vector3 spawnPosition = Vector3.zero;
        arBlocks = new List<GameObject>();

        foreach (int number in inputNumbers)
        {
            GameObject arBlock = Instantiate(arBlockPrefab, arObjectsParent);
            TextMeshPro textMeshPro = arBlock.GetComponentInChildren<TextMeshPro>();

            if (textMeshPro != null)
            {
                textMeshPro.text = number.ToString();
                arBlocks.Add(arBlock);
            }
            else
            {
                Debug.LogError("TextMeshPro component not found in AR block prefab.");
            }

            arBlock.transform.position = spawnPosition;
            spawnPosition += new Vector3(spacing, 0f, 0f);
        }
    }

    IEnumerator MergeSortVisualization(int low, int high)
    {
        if (low < high)
        {
            int mid = (low + high) / 2;

            // Visualize the division of arrays.
            yield return StartCoroutine(DivideArray(low, mid, high));

            yield return StartCoroutine(MergeSortVisualization(low, mid));
            yield return StartCoroutine(MergeSortVisualization(mid + 1, high));
            yield return StartCoroutine(Merge(low, mid, high));

            // Visualize the merged array.
            yield return StartCoroutine(MergeArray(low, mid, high));
        }
    }

    IEnumerator DivideArray(int low, int mid, int high)
    {
        // Move the blocks apart to visualize division.
        for (int i = low; i <= high; i++)
        {
            Vector3 currentPos = arBlocks[i].transform.position;
            Vector3 targetPos = new Vector3(currentPos.x, currentPos.y + 15.0f, currentPos.z);
            Color targetColor = GetColorForStep("Division");
            yield return StartCoroutine(MoveAndColorOverSeconds(arBlocks[i], currentPos, targetPos, animationSpeed, targetColor));
        }

        // Wait for some time to visualize the current step.
        yield return new WaitForSeconds(animationSpeed);
    }

    IEnumerator MergeArray(int low, int mid, int high)
    {
        // Move the blocks back to their original positions.
        for (int i = low; i <= high; i++)
        {
            Vector3 currentPos = arBlocks[i].transform.position;
            Vector3 targetPos = new Vector3(currentPos.x, currentPos.y - 7.0f, currentPos.z);
            Color targetColor = GetColorForStep("Merge");
            yield return StartCoroutine(MoveAndColorOverSeconds(arBlocks[i], currentPos, targetPos, animationSpeed, targetColor));
        }

        // Wait for some time to visualize the current step.
        yield return new WaitForSeconds(animationSpeed);
    }

    IEnumerator Merge(int low, int mid, int high)
    {
        int n1 = mid - low + 1;
        int n2 = high - mid;

        int[] leftArray = new int[n1];
        int[] rightArray = new int[n2];

        for (int x = 0; x < n1; ++x)
        {
            leftArray[x] = int.Parse(arBlocks[low + x].GetComponentInChildren<TextMeshPro>().text);
        }

        for (int y = 0; y < n2; ++y)
        {
            rightArray[y] = int.Parse(arBlocks[mid + 1 + y].GetComponentInChildren<TextMeshPro>().text);
        }

        int i = 0, j = 0;
        int k = low;

        while (i < n1 && j < n2)
        {
            if (leftArray[i] <= rightArray[j])
            {
                Color targetColor = GetColorForStep("Swap");
                yield return StartCoroutine(SwapNumbersVisual(arBlocks[k], leftArray[i], targetColor));
                i++;
            }
            else
            {
                Color targetColor = GetColorForStep("Swap");
                yield return StartCoroutine(SwapNumbersVisual(arBlocks[k], rightArray[j], targetColor));
                j++;
            }
            k++;

            // Wait for some time to visualize the current step.
            yield return new WaitForSeconds(animationSpeed);
        }

        while (i < n1)
        {
            Color targetColor = GetColorForStep("Swap");
            yield return StartCoroutine(SwapNumbersVisual(arBlocks[k], leftArray[i], targetColor));
            i++;
            k++;

            // Wait for some time to visualize the current step.
            yield return new WaitForSeconds(animationSpeed);
        }

        while (j < n2)
        {
            Color targetColor = GetColorForStep("Swap");
            yield return StartCoroutine(SwapNumbersVisual(arBlocks[k], rightArray[j], targetColor));
            j++;
            k++;

            // Wait for some time to visualize the current step.
            yield return new WaitForSeconds(animationSpeed);
        }


    }

    IEnumerator SwapNumbersVisual(GameObject arBlock, int newValue, Color targetColor)
    {
        Vector3 currentPos = arBlock.transform.position;
        Vector3 targetPos = new Vector3(currentPos.x, currentPos.y + 7.0f, currentPos.z);

        // Move the block up to visualize the swap.
        yield return StartCoroutine(MoveAndColorOverSeconds(arBlock, currentPos, targetPos, animationSpeed / 2.0f, targetColor));

        arBlock.GetComponentInChildren<TextMeshPro>().text = newValue.ToString();

        targetPos = new Vector3(currentPos.x, currentPos.y - 7.0f, currentPos.z);

        // Move the block down to its original position.
        yield return StartCoroutine(MoveAndColorOverSeconds(arBlock, currentPos, targetPos, animationSpeed / 2.0f, targetColor));
    }

    IEnumerator MoveAndColorOverSeconds(GameObject objectToMove, Vector3 start, Vector3 end, float seconds, Color targetColor)
    {
        float elapsedTime = 0;
        Color startColor = objectToMove.GetComponentInChildren<TextMeshPro>().color;

        while (elapsedTime < seconds)
        {
            objectToMove.transform.position = Vector3.Lerp(start, end, (elapsedTime / seconds));
            objectToMove.GetComponentInChildren<TextMeshPro>().color = Color.Lerp(startColor, targetColor, (elapsedTime / seconds));

            elapsedTime += Time.deltaTime;
            yield return null;
        }

        objectToMove.transform.position = end;
        objectToMove.GetComponentInChildren<TextMeshPro>().color = targetColor;
    }

    Color GetColorForStep(string step)
    {
        switch (step)
        {
            case "Division":
                return Color.blue;
            case "Merge":
                return Color.green;
            case "Swap":
                return Color.red;
            default:
                return Color.white;
        }
    }
}
