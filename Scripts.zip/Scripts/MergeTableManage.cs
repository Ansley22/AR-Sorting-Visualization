using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class MergeTableManage : MonoBehaviour
{
    public TextMeshProUGUI resultText;

    private List<string> steps = new List<string>();

    public void UpdateResultText(string step)
    {
        steps.Add(step);
        resultText.text = string.Join("\n", steps);
    }
}
