using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class BestBubble : MonoBehaviour
{
    public GameObject arBallPrefab;
    public Transform arObjectsParent;
    public float spacing = 1.0f;
    public float animationSpeed = 1.0f;

    private List<GameObject> arBalls;

    void Start()
    {
        // Step 1: Spawn AR Balls based on the best-case scenario (already sorted).
        SpawnARObjectsBestCase();

        // Step 2: Sort AR Balls using Bubble Sort (Best Case).
        StartCoroutine(BubbleSortBestCase());
    }

    // Step 1: Spawn AR Balls based on the best-case scenario (already sorted).
    void SpawnARObjectsBestCase()
    {
        int[] inputNumbers = { 1, 2, 3, 4, 5 }; // Best-case scenario
        Vector3 spawnPosition = Vector3.zero;

        arBalls = new List<GameObject>();

        foreach (int number in inputNumbers)
        {
            GameObject arBall = Instantiate(arBallPrefab, arObjectsParent);
            TextMeshPro textMeshPro = arBall.GetComponentInChildren<TextMeshPro>();

            if (textMeshPro != null)
            {
                textMeshPro.text = number.ToString();
                arBalls.Add(arBall);
            }
            else
            {
                Debug.LogError("TextMeshPro component not found in AR ball prefab.");
            }

            arBall.transform.position = spawnPosition;
            spawnPosition += new Vector3(spacing, 0f, 0f);
        }
    }

    // Step 2: Bubble Sort AR Balls (Best Case).
    IEnumerator BubbleSortBestCase()
    {
        int n = arBalls.Count;
        bool swapped;

        for (int i = 0; i < n - 1; i++)
        {
            swapped = false;

            for (int j = 0; j < n - i - 1; j++)
            {
                GameObject ball1 = arBalls[j];
                GameObject ball2 = arBalls[j + 1];

                TextMeshPro text1 = ball1.GetComponentInChildren<TextMeshPro>();
                TextMeshPro text2 = ball2.GetComponentInChildren<TextMeshPro>();

                int number1;
                int number2;

                if (int.TryParse(text1.text, out number1) && int.TryParse(text2.text, out number2))
                {
                    // Highlight the compared balls by changing their color to blue (representing best-case)
                    ChangeColor(text1, Color.blue);
                    ChangeColor(text2, Color.blue);

                    // Highlight the compared balls by increasing their size
                    yield return StartCoroutine(ScaleOverSeconds(ball1, new Vector3(1.5f, 1.5f, 1.5f), animationSpeed));
                    yield return StartCoroutine(ScaleOverSeconds(ball2, new Vector3(1.5f, 1.5f, 1.5f), animationSpeed));

                    yield return new WaitForSeconds(animationSpeed);

                    // No swaps needed in the best-case scenario

                    // Reset the color after comparison
                    ChangeColor(text1, Color.white);
                    ChangeColor(text2, Color.white);

                    // Reset the size after comparison
                    yield return StartCoroutine(ScaleOverSeconds(ball1, Vector3.one, animationSpeed));
                    yield return StartCoroutine(ScaleOverSeconds(ball2, Vector3.one, animationSpeed));

                    // Wait for some time to visualize the current step.
                    yield return new WaitForSeconds(animationSpeed);
                }
                else
                {
                    Debug.LogError("Invalid number format for Text1 or Text2.");
                }
            }

            // If no two elements were swapped by inner loop, the array is already sorted
            if (!swapped)
                break;

        }

        // Change the color of all balls to green to indicate sorting completion
        foreach (GameObject arBall in arBalls)
        {
            TextMeshPro textMeshPro = arBall.GetComponentInChildren<TextMeshPro>();
            ChangeColor(textMeshPro, Color.green);
        }
    }

    // Change the color of TextMeshPro component
    void ChangeColor(TextMeshPro text, Color color)
    {
        if (text != null)
        {
            text.color = color;
        }
    }

    // Move AR Ball over a period of seconds.
    IEnumerator MoveOverSeconds(GameObject objectToMove, Vector3 start, Vector3 end, float seconds)
    {
        float elapsedTime = 0;

        while (elapsedTime < seconds)
        {
            objectToMove.transform.position = Vector3.Lerp(start, end, (elapsedTime / seconds));
            elapsedTime += Time.deltaTime;
            yield return new WaitForEndOfFrame();
        }

        objectToMove.transform.position = end;
    }

    // Scale AR Ball over a period of seconds.
    IEnumerator ScaleOverSeconds(GameObject objectToScale, Vector3 startScale, float seconds)
    {
        Vector3 endScale = objectToScale.transform.localScale;

        float elapsedTime = 0;

        while (elapsedTime < seconds)
        {
            objectToScale.transform.localScale = Vector3.Lerp(startScale, endScale, (elapsedTime / seconds));
            elapsedTime += Time.deltaTime;
            yield return new WaitForEndOfFrame();
        }

        objectToScale.transform.localScale = endScale;
    }
}
