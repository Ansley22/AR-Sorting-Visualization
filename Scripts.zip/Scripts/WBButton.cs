using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WBButton : MonoBehaviour
{
      public void SortGame()
	{
		SceneManager.LoadSceneAsync(7);
	}

}
